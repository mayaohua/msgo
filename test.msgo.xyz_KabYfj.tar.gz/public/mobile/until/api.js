const Host = 'https://wx.1001020.cn/api/';
export default {
	Host: Host
}