<?php

use App\Models\Setting;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SettingTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // $jobForm = [];
        // $jobForm['find_rules'] = [];
        // $jobForm['find_number'] = 10;
        // $jobForm['find_cron'] = '* * * * *';
        // Setting::create([
        //     'key' => 'jobForm',
        //     'value' => json_encode($jobForm)
        // ]);
        // $wxForm = [
        //     'zixunList'=>[],
        //     'gonggao'=>''
        // ];
        // Setting::create([
        //     'key' => 'wxForm',
        //     'value' => json_encode($wxForm)
        // ]);
        // $backForm = [
        //     'channel'=>''
        // ];
        Setting::create(['key' => 'app_profit','value' => '10']);
        Setting::create(['key' => 'user_profit','value' => '10']);
        Setting::create(['key' => 'user_app_profit','value' => '10']);

        
    }
}
