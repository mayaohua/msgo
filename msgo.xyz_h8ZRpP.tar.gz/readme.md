0: {goodsId: "981910298240", attrCode: "A000011", attrName: "首月资费方式", attrValCode: "A000011V000003",…}
attrCode: "A000011"
attrName: "首月资费方式"
attrValCode: "A000011V000003"
attrValDesc: "套餐包外资费"
attrValName: "套餐包外资费"
eopAttrCode: "FirstMonBillMode"
goodsId: "981910298240"
1: {goodsId: "981910298240", attrCode: "A000011", attrName: "首月资费方式", attrValCode: "A000011V000001",…}
attrCode: "A000011"
attrName: "首月资费方式"
attrValCode: "A000011V000001"
attrValDesc: "全月套餐"
attrValName: "全月套餐"
eopAttrCode: "FirstMonBillMode"
goodsId: "981910298240"
2: {goodsId: "981910298240", attrCode: "A000011", attrName: "首月资费方式", attrValCode: "A000011V000002",…}
attrCode: "A000011"
attrName: "首月资费方式"
attrValCode: "A000011V000002"
attrValDesc: "套餐减半"
attrValName: "套餐减半"
eopAttrCode: "FirstMonBillMode"
goodsId: "981910298240"

feeName: "全月套餐"
feeVal: "A000011V000001"
feeDesc: ""





