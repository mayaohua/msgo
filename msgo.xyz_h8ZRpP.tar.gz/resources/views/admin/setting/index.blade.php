@extends('layouts.admin')

@section('style')
<style>
    .ui-wx .item{
       margin-bottom:20px;
    }
    .ui-wx .item .el-form-item__content{
      display:flex;
     
    }
    .ui-wx .item .el-form-item__content .el-input{
      margin-right:10px;
    }
</style>
@endsection
@section('content')

<div id="container">
    <el-tabs v-model="activeName" >
        <el-tab-pane label="号码设置" name="mobile_form">
            <el-form label-position="top" :model="mobileForm" ref="mobileForm" :rules="rules" label-width="100px" >
              <input type="file" @change="getFile($event)" hidden accept=".png,.jpg,.jpeg">
              <el-form-item label="轮播图设置">
                <el-collapse accordion>
                  <el-collapse-item v-for="(item, index) in mobileForm.zixunList">
                    <template slot="title">
                      <span>公告 @{{index+1}}</span><el-link type="danger" @click.stop="removeZixun(item)" style="position: absolute;right: 35px;" >删除此项</el-link>
                    </template>
                    <div style="display: flex;align-items:center;" >
                      <el-link type="primary" @click="inputClick(index)" style="width: 180px;margin-right:10px;">上传图片</el-link>
                      <el-input  size="mini" style="margin-right: 10px;" v-model="item.src" placeholder="请输入图片地址"></el-input>
                      <el-input v-model="item.url" size="mini" placeholder="请输入链接地址"></el-input>
                    </div>
                  </el-collapse-item>
                </el-collapse>
                <el-button type="success" @click.prevent="addZixun()"  size="small">增加一项</el-button>
              </el-form-item>
                <el-form-item>
                    <el-button type="primary" @click="submitForm('mobileForm')">立即提交</el-button>
                </el-form-item>
            </el-form>
        </el-tab-pane>
        <el-tab-pane label="充值设置" name="wx_form" class="ui-wx">
          <el-form label-position="top" :model="wxForm" ref="wxForm" :rules="rules" label-width="100px" >
            <el-form-item label="商品分类设置">
              <el-collapse accordion>
                <el-collapse-item v-for="(item, index) in wxForm.caseList">
                  <template slot="title">
                    <span>@{{item.name}}  <span style="margin-left: 10px;"></span>
                    <span style="margin-left: 5px;">未分组@{{unChoseeCseList(item).length}}个</span>
                    <div  style="position: absolute;right: 35px;display:inline-block">
                      <el-button type="text" @click.stop="tagTemp.dialogVisible = true;tagTemp.pindex = index;tagTemp.edit=false;tagTemp.data.name='';tagTemp.data.desc='';">添加分组</el-button>
                    </div>
                  </template>
                  <div>
                    <el-card class="box-card" v-for="(ite, ind) in item.items">
                      <div slot="header" class="clearfix">
                        <span>@{{ite.name}}</span>
                        <span style="margin-left: 5px;">详细：</span>
                        <span>@{{ite.desc}}</span>
                        <el-link  type="danger" style="float: right; padding: 3px 0" type="text" @click.stop="removeCaseGroup(index,ind)">删除分组</el-link>
                        <el-link  type="primary" style="float: right; padding: 3px 0;margin-right: 10px;" type="text" @click.stop="tagTemp.dialogVisible = true;tagTemp.pindex = index;tagTemp.edit=true;tagTemp.data.name=ite.name;tagTemp.data.desc=ite.desc;tagTemp.cindex=ind;">修改分组</el-link>

                      </div>
                      <div class="text item" >
                        <el-tag
                          v-for="(tag,i) in ite.value"
                          :key="tag.id"
                          style="margin-left: 5px;"
                          closable
                          @close="handleTagClose(index,ind,i)"
                          >
                          @{{tag.name}}
                        </el-tag>
                        <p style="margin: 10px 0;" v-show="unChoseeCseList(item).length>0">未选择</p>
                        <el-tag style="margin-left: 5px;cursor: pointer;" v-for="its in unChoseeCseList(item)" type="warning" :key="its.id" @click="handleAddTag(index,ind,its)">@{{its.name}}</el-tag>
                        {{-- <el-button class="button-new-tag" size="small" @click="tagTemp.showTagChosee">+ 添加</el-button> --}}
                      </div>
                    </el-card>
                    {{-- <el-button style="margin-top: 10px;" type="success" @click.prevent="addZixun()"  size="small">增加一项</el-button> --}}
                  </div>
                </el-collapse-item>
              </el-collapse>
              
            </el-form-item>
                <el-form-item >
                    <el-button type="primary" @click="submitForm('wxForm')">立即提交</el-button>
                </el-form-item>
            </el-form>
        </el-tab-pane>
        <el-tab-pane label="系统设置" name="back_form">
            <el-form label-position="top" :model="backForm" ref="backForm" :rules="rules" label-width="100px" >
              <el-form-item label="推荐人编号">
                    <el-input v-model="backForm.channel" type="text" placeholder="请输入推荐人编号"></el-input>
              </el-form-item>
              <el-form-item>
                    <el-button type="primary" @click="submitForm('backForm')">立即提交</el-button>
                </el-form-item>
            </el-form>
        </el-tab-pane>
    </el-tabs>
</el-form>

<el-dialog
  title="提示"
  :visible.sync="tagTemp.dialogVisible"
  width="30%"
  :before-close="handleClose">
  <div>
      <el-form ref="form" label-position="top" :model="tagTemp.data" label-width="80px">
        <el-form-item label="分组名称">
            <el-input type="text" v-model="tagTemp.data.name"></el-input>
        </el-form-item>
        <el-form-item label="分组详细">
          <el-input type="textarea" v-model="tagTemp.data.desc"></el-input>
      </el-form-item>
    </el-form>
  </div>
  <span slot="footer" class="dialog-footer">
    <el-button @click="tagTemp.dialogVisible = false">取 消</el-button>
    <el-button type="primary" @click="addCaseGroup">确 定</el-button>
  </span>
</el-dialog>
</div>
@endsection

@section('script')
<script type="text/javascript">
    new Vue({
        el:"#app",
        data:{
            mobileForm: {!! $mobileForm !!},
            wxForm: {!! $wxForm !!},
            // wxForm: {
            //   "caseList" : [{
            //     "name":'联通',
            //     "id":200,
            //     "items":[]
            //   },{
            //     "name":'移动',
            //     "id":201,
            //     "items":[]
            //   },{
            //     "name":'电信',
            //     "id":202,
            //     "items":[]
            //   }]
            // },
            backForm: {!! $backForm !!},
            activeName: 'mobile_form',
            allCase:{!! $allCase !!},
            tagTemp:{
              dialogVisible:false,
              pindex:0,
              cindex:0,
              data:{
                name:'',
                desc:''
              }
            },
            tempZiXun: {
              index:0,
              imgPath:''
            },
            rules: {
              find_number: [
                { required: true, message: '查询数量必填', trigger: 'blur' },
              ]
          }
        },
        computed :{
          unChoseeCseList(){
            var _this = this;
            return function(item){
              for (let index = 0; index < _this.allCase.length; index++) {
                const element = _this.allCase[index];
                if(element.id === item.id){
                  let b = _this.getValues(item.items)
                  return _this.getUnChoseeValues(element.value,b);
                  break;
                }
              }
              return []
            }
          },
        },
        methods: {
          addCaseGroup(){
            if(this.tagTemp.data.name == null || this.tagTemp.data.name == '' ){
              this.$message.error('分组名称不能为空');return false;
            }
            if(this.tagTemp.edit){
              var d =this.wxForm.caseList[this.tagTemp.pindex].items[this.tagTemp.cindex];
              d.name = this.tagTemp.data.name
              d.desc = this.tagTemp.data.desc
            }else{
              this.wxForm.caseList[this.tagTemp.pindex].items.push({
                name:this.tagTemp.data.name,
                desc:this.tagTemp.data.desc,
                value:[]
              });
            }
            
            this.tagTemp.dialogVisible = false;
          },
          removeCaseGroup(index,ind){
            this.wxForm.caseList[index].items.splice(ind,1)
            // console.log(data)
          },
          handleTagClose(index,ind,i){
            this.wxForm.caseList[index].items[ind].value.splice(i,1)
          },
          handleAddTag(index,ind,item){
            this.wxForm.caseList[index].items[ind].value.push(item)
          },
           getValues(items){
              let arr = [];
              for (let index = 0; index < items.length; index++) {
                const element = items[index];
                arr = arr.concat(element.value)
              }
              return arr;
           },
           getUnChoseeValues(a,b){
             var arr = [];
             for (let index = 0; index < a.length; index++) {
               let element = a[index];
               let has = false;
               for (let aa = 0; aa < b.length; aa++) {
                 let ee = b[aa];
                 if(element.id === ee.id){
                   has = true;
                   break;
                 }
               }
               if(!has){
                 arr.push(element)
               }
               
             }
             return arr;
           },
           submitForm(formName){
                this.$refs[formName].validate((valid) => {
                if (valid) {
                    this.$axios.post('/Setting/index/'+formName,this[formName])
                } else {
                    return false;
                }
                });
           },
           addZixun(){
              this.mobileForm.zixunList.push({
                src: '',
                url: '',
              });
           },
           removeZixun(item){
             if(this.mobileForm.zixunList.length == 1){
              this.$message({
                  type: 'error',
                  message: '至少保留一个'
              });return;
             }
             var index = this.mobileForm.zixunList.indexOf(item)
              if (index !== -1) {
                this.mobileForm.zixunList.splice(index, 1)
              }
           },
           getFile(event){
                var file = event.target.files;
                var imgName = file[0].name;
                this.tempZiXun.imgPath = [];
                var idx = imgName.lastIndexOf(".");  
                if (idx != -1){
                    var ext = imgName.substr(idx+1).toUpperCase();   
                    ext = ext.toLowerCase( ); 
                    if (ext!='png' && ext!='jpg' && ext!='jpeg'){
                      this.$message({
                          type: 'wraing',
                          message: '请上传图片格式不正确'
                      });
                    }else{
                      this.tempZiXun.imgPath = file[0];
                      this.uploadziXunImg()
                    }   
                }
          },
          inputClick(index){
            this.$refs['mobileForm'].$el.querySelector('input[type="file"]').click();
            this.tempZiXun.index = index;
          },
           uploadziXunImg(){
            let config = {
              headers: {
                'Content-Type': 'multipart/form-data'
              }
            };
            var formData = new FormData();
            formData.append('fileUpload',this.tempZiXun.imgPath)
            this.$axios.post('/Setting/upload',formData,config).then((res) => {
              this.mobileForm.zixunList[this.tempZiXun.index].src= res.data.path
            })
           }
        },
    })
</script>
@endsection