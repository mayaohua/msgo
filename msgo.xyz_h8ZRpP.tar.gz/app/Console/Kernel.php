<?php

namespace App\Console;

use App\Events\JobWork;
use App\Models\Setting;
use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;
use Illuminate\Support\Facades\Log;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        Commands\OrderStatusCommand::class
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        
        $schedule->command('order:update close')->everyMinute();//关闭支付
        $schedule->command('order:update pay')->everyMinute();//支付
        $schedule->command('order:update bill')->everyMinute();//支付成功，未充值
        $schedule->command('order:update receive')->everyMinute();//退款   延迟20分钟  //30分钟执行一次
        $schedule->command('order:update threepay')->everyMinute();//充值
        $schedule->command('order:update sys_bill')->hourly();//同步价格
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
