<?php
namespace App\Services;
use App\Services\BaseService;
use App\Events\JobWork;
use Illuminate\Support\Facades\Log;
use App\Models\PhoneBillOrder;
use EasyWeChat\Factory;
use App\Models\BillType;
use App\Models\Bill;
use App\Models\BillData;
use Illuminate\Support\Facades\DB;

class BillService extends BaseService{
    protected static $_URL = 'http://aa.cz500.top/unicomAync';
    protected static $_userId = '543';
    protected static $_privatekey = 'c8a42e87bb05364c7fd205c4d1bbeb6ffb4e2282e30018177cc295c3e9c8420d';
    protected static $_header = ['Accept: application/json;charset=UTF-8;'];



    /**
     * 转接到平台充值
     */
    public function mobileBill($order_id){
        
        $orderDb = PhoneBillOrder::find($order_id);
        if(!$orderDb){
            return ;
        }
        $bill_data = json_decode($orderDb->bill_data);
        $res = $this->buy($bill_data);
        if(!$res['success']){
            $fail_msg = isset($res['desc'])?$res['desc']:'充值失败,发起退款';
            $this->refund($orderDb,$fail_msg);
        }else{
            $status = 5;
            $msg = false;
            $orderDb->changeStatus($status,$msg);
            $orderDb->bill_biz_order_id = $res['bizOrderId'];
            $orderDb->save();
        }
    }
    
    public function refund($orderDb,$fail_msg){
        
        //首先充值失败了，然后退款
        $status = 4;
        $orderDb->changeStatus($status,$fail_msg);

        //发起退款
        Log::info('发起退款');
        $out_refund_no = md5(time());
        $total_fee = bcmul($orderDb->bill_money , 100 ,0);
        $app = Factory::payment(config('wechat.payment.default'));
        
        $result = $app->refund->byOutTradeNumber($orderDb->bill_app_order_id, $out_refund_no , $total_fee , $total_fee, [
            'refund_desc' => '充值失败,发起退款',
            'notify_url'  => config('wechat.payment.default.reback_notify_url'),
        ]);
        if($result['return_code'] == 'SUCCESS'){
            if(isset($result['result_code']) && $result['result_code'] == 'SUCCESS'){
                
                $status = 6;
                $msg = '充值异常，发起退款';
                $orderDb->changeStatus($status,$msg);
                return ;
            }
        }
        $status = 8;
        $msg = '发起退款失败';
        $orderDb->changeStatus($status,$msg);
    }

    public function sysBillData(){
        //同步充值数据
        DB::beginTransaction();
        $service_data = $this->getBillCase();
        // dd($service_data);
        Bill::where('id','>','0')->update(['stop_sale'=>1]);
        foreach($service_data as $value){
            $billType = BillType::find($value['type_id'])->first();
            if(!$billType){continue;}
            foreach($value['data'] as $v){
                $bill = Bill::where('itemId',$v['id'])->with('sell_data')->get();
                foreach($bill as $b){
                    $o = bcdiv($v['itemSalesPrice'],$v['itemFacePrice'], 3);
                    $o = bcmul($o,100, 2);
                    $zk = floatval($o);
                    $b->itemProfit = $zk;
                    $b->stop_sale = 0;
                    $b->itemFacePrice = $v['itemFacePrice'];
                    $sell_data = $this->getSellData($b);
                    $b->sell_data->update($sell_data);
                    $b->save();
                }

            }
        }
        DB::commit();
       
    }

    private function getSellData($value){
        //商品面值
        $sell_data  = (object) [];
        $facePrice = floatval(bcdiv($value->itemFacePrice , 1000, 3));
        $sell_data->facePrice = $facePrice;
        //商品折扣率
        $bill_profit = $value->itemProfit;
        if($bill_profit == -1){
            $bill_profit = BillCase::find($value->bill_case_id)->first()->item_profit;
        }
        $bill_profit = floatval(bcdiv($bill_profit , 100, 3));
        //进货价
        $sell_data->itemSalePrice = floatval(bcmul($facePrice,$bill_profit,2));
        //剩余利润 
        $sell_data->itemFreePrice = floatval(bcsub($facePrice , $sell_data->itemSalePrice,2));
        //平台利润率
        $app_profit_later = $value->app_profit;
        if($value->app_profit == -1){
            $app_profit_later = Setting::where('key','app_profit')->first()->app_profit;
        }
        $app_profit_later = floatval(bcdiv($app_profit_later , 100, 3));
        //平台出售利润
        $sell_data->AppFreePrice = floatval(bcmul($sell_data->itemFreePrice , $app_profit_later,2));
        //平台出售价
        $sell_data->AppSalePrice = floatval(bcadd($sell_data->AppFreePrice , $sell_data->itemSalePrice,2));

        //分销者利润率
        $user_profit_later = $value->user_profit;
        if($value->user_profit == -1){
            $user_profit_later = Setting::where('key','user_profit')->first()->user_profit;
        }
        $user_profit_later = floatval(bcdiv($user_profit_later , 100, 3));
        //分销剩余利润
        $ProfixFreePrice = $sell_data->ProfixFreePrice = floatval(bcmul($sell_data->itemFreePrice , $user_profit_later,2));
        // dd($ProfixFreePrice);
        //分销者出售平台利润率
        $user_app_profit_later = $value->user_app_profit;
        if($value->user_app_profit == -1){
            $user_app_profit_later = Setting::where('key','user_app_profit')->first()->user_app_profit;
        }
        $user_app_profit_later = floatval(bcdiv($user_app_profit_later , 100, 3));
        
        //分销者出售平台利润
        $sell_data->UserAppFreePrice = floatval(bcmul($ProfixFreePrice , $user_app_profit_later,2));
        
        //分销者利润
        $sell_data->UserFreePrice = floatval(bcsub($ProfixFreePrice , $sell_data->UserAppFreePrice,2));
        //分销者出售价
        $sell_data->UserSalePrice = floatval(bcadd($sell_data->ProfixFreePrice , $sell_data->itemSalePrice,2));
        return (array) $sell_data;
    }

    public function getBillCase(){
        $arr = [
            [
                'name'=>'联通',
                'type_id' => '3',
                'data' => $this->getCase(['bizId'=>200])
            ],
            [
                'name'=>'电信',
                'type_id' => '2',
                'data' => $this->getCase(['bizId'=>202])
            ],
            [
                'name'=>'移动',
                'type_id' => '1',
                'data' => $this->getCase(['bizId'=>201])
            ],
            [
                'name'=>'会员',
                'type_id' => '4',
                'data' => $this->getCase(['bizId'=>3500])
            ],
            [
                'name'=>'联通',
                'type_id' => '7',
                'data' => $this->getCase(['bizId'=>100])
            ],
            [
                'name'=>'电信',
                'type_id' => '6',
                'data' => $this->getCase(['bizId'=>101])
            ],
            [
                'name'=>'移动',
                'type_id' => '5',
                'data' => $this->getCase(['bizId'=>102])
            ],
        ];
        return $arr;
    }

    public function getAllCase(){
        $arr = array_merge($this->getCase(['bizId'=>200]),$this->getCase(['bizId'=>202]),$this->getCase(['bizId'=>201]));
        foreach($arr as $index => $value){
            $arr[$index]['info'] = '72小时到账';
            $arr[$index]['itemSalesPrice'] = $value['itemFacePrice'];
            
        }
        // dd($arr);
        return $arr;
    }

    public function buy($info){
        $url = self::$_URL.'/buy.do';
        $dtCreate = date('YmdHis');
        $data = [
            'userId' => self::$_userId,
            'itemId' => $info->itemId,//商品ID
            'checkItemFacePrice' => $info->itemFacePrice,//商品面值
            'uid'=>$info->bill_mobile,//充值手机号
            'serialno'=>$info->bill_app_order_id,//合作方商户系统的流水号
            'dtCreate' => $dtCreate,
        ];
        ksort($data);
        foreach($data as $key => $value){
            if(isset($data['sign'])){
                $data['sign'] .= $value;
            }else{
                $data['sign'] = '';
                $data['sign'] = $value;
            }
            
        }
        $data['sign'].= self::$_privatekey;
        $data['sign'] = md5($data['sign']);
        $result = parent::curl_request($url.'?'.http_build_query($data),'',self::$_header);
        $result = json_decode($result,1);
        $success = false;
        if($result['code'] == '00'  || $result['code'] == '23' || $result['code'] == '31'){
            $success = true;
        }
        $result['success'] = $success;
        return $result;
    }

    public function queryOrder($bill_app_order_id){
        $url = self::$_URL.'/queryBizOrder.do';
        $data = [
            'userId' => self::$_userId,
            'serialno' => $bill_app_order_id,
            'sign' => md5($bill_app_order_id.self::$_userId.self::$_privatekey)  
        ];
        $result = parent::curl_request($url.'?'.http_build_query($data),'',self::$_header);
        $result = json_decode($result,1);
        return $result;
    }

    public function surplus(){
        $url = self::$_URL.'/queryBalance.do';
        $data = [
            'userId' => self::$_userId,
            'sign' => md5(self::$_userId.self::$_privatekey)  
        ];
        $result = parent::curl_request($url.'?'.http_build_query($data),'',self::$_header);
        $result = json_decode($result);
        return $result;
    }

    public function getCase($info){
        $url = 'http://aa.cz500.top'.'/common/queryUserItemList.do';
        $data = [
            'userId' => self::$_userId,
            'bizId' => $info['bizId'],
            'sign' => md5($info['bizId'].self::$_userId.self::$_privatekey)  
        ];
        $result = parent::curl_request($url.'?'.http_build_query($data),'',self::$_header);
        $result = json_decode($result,1);
        return $result['data'];
    }

    private function creatOrderId(){
        return date('Ymd').substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 8);
    }
}
