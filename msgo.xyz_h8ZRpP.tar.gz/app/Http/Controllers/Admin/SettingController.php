<?php

namespace App\Http\Controllers\Admin;

use App\Models\Rule;
use App\Models\Setting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class SettingController extends Controller
{

    private static $rule_list;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        self::$rule_list = config('rule');
        $this->middleware('auth');
    }


    public function index(){

        $settingObj = Setting::where('key','mobileForm')->first();
        $mobileForm =$settingObj->value ? $settingObj->value : '{}';
        
        $settingObj = Setting::where('key','wxForm')->first();
        $wxForm = $settingObj->value ? $settingObj->value : '{}';

        $settingObj = Setting::where('key','backForm')->first();
        $backForm = $settingObj->value ? $settingObj->value : '{}';

        $allCase = $this->getAllCase();
        return view('admin.setting.index',compact(['mobileForm','wxForm','backForm','allCase']));
    }



    public function getAllCase(){
        $data = config('billcase.items');
        $arr = [
            [
                'name' => '联通',
                'id' => 200,
                'value' => []
            ],[
                'name' => '移动',
                'id' => 201,
                'value' => []
            ],
            [
                'name' => '电信',
                'id' => 202,
                'value' => []
            ]
        ];
        foreach($data as $index => $value){
            $arrt = [200,201,202];
            $iii = array_search($value['bizId'],$arrt);
            $arr[$iii]['value'][] = [
                'name' => $value['itemName'].'['.$value['id'].']',
                'id' => $value['id']
            ];
        }
        return json_encode($arr);
    }

    public function indexAction(Request $request){
        //任务设置
        $type = $request->route('type');
        switch ($type) {
            case 'mobileForm':
                $data = $request->only(['zixunList']);
                foreach($data['zixunList'] as $index => $value){
                    if($value['src'] == null){
                        unset($data['zixunList'][$index]);
                    }
                }
                if(count($data['zixunList']) == 0){
                    return $this->fail('轮播图片不能为空');
                }
                $res = Setting::where('key','mobileForm')->update(['value'=>json_encode($data)]);
                if($res){
                    return $this->success();
                }
                return $this->fail();
                
                break;
            case 'wxForm':
                $data = $request->only(['caseList']);
                $res = Setting::where('key','wxForm')->update(['value'=>json_encode($data)]);
                if($res){
                    return $this->success();
                }
                return $this->fail();
                break;
            case 'backForm':
                $data = $request->only(['channel']);
                $res = Setting::where('key','backForm')->update(['value'=>json_encode($data)]);
                if($res){
                    return $this->success();
                }
                break;
            default:
                # code...
                break;
        }
        return $this->success(["type" => $type]);
    }
    public function uploadAction(Request $request){
        $file = $request->file('fileUpload');
        if($file->isValid())
        {
            $ext = $file->getClientOriginalExtension();//后缀
            $path = $file->getRealPath();//路径
            $filename = date('Y-m-d-H-i-s').'.'.$ext;//重命名
            Storage::disk('uploads')->put($filename, file_get_contents($path));//上传
        }
        return $this->success(['path'=>Storage::disk('uploads')->url($filename)]);
    }
}