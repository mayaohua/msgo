<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Session;
use EasyWeChat\Factory;

class WxAuth
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string|null  $guard
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = null)
    {
        $app = Factory::officialAccount(config('wechat.official_account.default'));
        $user = Session::get('wechat_user');
        if(!$user) {
            Session::put('target_url', $request->getRequestUri());
            Session::save();
            $redirectUrl = $app->oauth->scopes(['snsapi_userinfo'])->redirect();
            // dd($request->getRequestUri());
            return $redirectUrl;
        }
        return $next($request);
    }
}
